import React, { useState, Fragment } from 'react';
import * as Icon from 'react-bootstrap-icons';
import AddUserForm from './forms/AddUserForm';
import EditUserForm from './forms/EditUserForm';
import TableForm from './tables/TableForm';
import general from './forms/general';

const App = () => {
	// Data
	const usersData = [//declaring a variable userData with data
		{ 
		id: 1, 
		name: 'Grace', 
		Date_created: 'Juth',
		Time_created: '12:23:01',
		operate: 'abel',
		works: '11.20.10.1'},
		{
	 id: 2, 
	 name: 'Binde', 
	 Date_created: '1:07:2020',
	 Time_created: '11:23:01',
	 operate: 'Joel',
	 works: '13.20.10.1'},
		{ 
	   id: 3, 
	   name: 'Ben', 
	   Date_created: '20:07:2020',
	   Time_created: '2:23:01',
	   operate: 'babel',
	   works: '2.20.10.1'},
	]
//decalring this variable to hold the initial form state of default values
	const initialFormState = { 
		id: null, 
		name: '', 
		Date_created: '',
		Time_created: '',
		opearte: '',
		works: ''}

	// Setting state
	const [ users, setUsers ] = useState(usersData)//passing te argument
	const [ currentUser, setCurrentUser ] = useState(initialFormState)
	const [ editing, setEditing ] = useState(false)//preventing editing 
	//by setting the state to false

	// CRUD operations
	const addUser = user => {
		user.id = users.length + 1// increment/looping through the users data
		setUsers([ ...users, user ])// setting the data from the users
		//which ws initially passed by the usersData
	}

	const deleteUser = id => {
		setEditing(false)//to prevent editing
//used of filter method injavascript to check if the user.Id and Id are the same
		setUsers(users.filter(user => user.id !== id))//comparing the two user.Id and the existing Id
	}

	const updateUser = (id, updatedUser) => {
		setEditing(false)// to prevent editng
//settings users in array format using the map the method in javascript
//the map method create an array 
		setUsers(users.map(user => (user.id === id ? updatedUser : user)))

	}
//this stage is to edit the values by setEditing to true
	const editRow = user => {
		setEditing(true)
//setting the value for the current user
		setCurrentUser({ 
		id: user.id, 
		name: user.name,
		Date_created: user.Date_created,
		Time_created: user.Time_created,
		operate: user.operate,
		works: user.works 
		})
	}

	return (
		<div className="container">
			<h1>Crud Application using React</h1>
			<hr />
			<div className="flex-row">
				<div className="flex-large">
					{editing ? (
						<Fragment>
							<h2>Edit user</h2>
							
							<EditUserForm
								editing={editing}//fragment to group similar child list 
								//without the used of DOM
								setEditing={setEditing}
								currentUser={currentUser}
								updateUser={updateUser}
							/>
						</Fragment>
					) : (
						<Fragment>
							 <h1>Add User</h1>
							<AddUserForm addUser={addUser} />
						</Fragment>
					)}
				</div>
				<div className="flex-large">
					<h2>Users List</h2>
					<TableForm users={users} editRow={editRow} deleteUser={deleteUser} />
				</div>
			</div>
		</div>
	);
};
//always set the default export for each file
export default App;
