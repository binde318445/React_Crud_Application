import React, { useState } from 'react';
 

//declaring a  variables with constant, using props to pass data from one component
//to another.
const AddUserForm = props => {
	//props is an object
	//declaring another variables to hold the initial form values, empty.
	const initialFormState = { 
		id: null, 
		name: '', 
		Date_created: '',
		Time_created: '', 
		operate: '',
		works: ''}
		//declaring another attribute with useState to accept argument of the 
		//initialFormstate
	const [ user, setUser ] = useState(initialFormState)
//
	const handleInputChange = event => {
		//am targetting event for each input value when submitting form.
		const { name, value } = event.target

		setUser({ ...user, [name]: value })//setting each value to its input type.

	};

	return (//this a method to return the result/output used in javascripts
	<div className="container">
       <div className="shadow p-5">
		<form class="form-inline"
			onSubmit={event => {
				event.preventDefault()//this method to deter the default action from happening
				if (!user.name || //if none of the value is addded? 
					!user.Date_created || 
					!user.Time_created || 
					!user.operate || 
					!user.works) 
			   return
				props.addUser(user)//add this atributes 
				setUser(initialFormState)//set the initial formState
			}}
		>
			<label><b>Comp_Name:</b></label>
			<div className="form-group">
			<input type="text" name="name"
			     
			    required="required" 
			    className="form-control" 
			    placeholder="Enter your name" 
			    value={user.name} onChange={handleInputChange} />
			</div>
			<div className="form-group">
			<label class="one"><b>Record_Date:</b></label>
			<input type="date" name="Date_created"
			    required="required" 
			    placeholder="DD:MM:YY" 
			    className="form-control form-control-sm" 
			    value={user.Date_created} onChange={handleInputChange} />
			</div>
			<div className="form-group">
			<label><b>Time_created:</b></label>
			<input type="time" name="Time_created"
			class="clean" 
			     required="required" placeholder="H:M:S" 
			     className="form-control form-control-sm" 
			     value={user.Time_created} onChange={handleInputChange} />
			</div>
			<div className="form-group">
			<label class="adjust"><b>Operator:</b></label>
			<input type="text" name="operate" 
			     class="green"
			     required="required" placeholder="Enter operator name" 
				 className="form-control form-control-sm" 
				 //to handle when the value of an input element is change
			     value={user.operate} onChange={handleInputChange} />
			</div>
			<div className="form-group">
			<label><b>Workstation:</b></label>
			<input type="text" name="works" 
			    required="required" 
			    placeholder="Enter workstation" 
			    className="form-control form-control-sm" 
			    value={user.works} onChange={handleInputChange} />
			</div>
			<button className="btn btn-primary"><span class="glyphicon glyphicon-pencil">Add User</span></button>
		</form>
		</div>
      </div>
	
	);
};
//always include the default export of each file to be 
//imported to the app.js
export default AddUserForm;
