import React, { useState, useEffect } from 'react';
//useState brings state to functional component
//useEffect 

//declaring a variable EditUserForm and passing the props to the data
const EditUserForm = props => {
	//this is the state
  const [ user, setUser ] = useState(props.currentUser)//
//this is the effect based on the changes that will take place in my forms
  useEffect(
    () => {
      setUser(props.currentUser)//setting the props of currentUser
    },
    [ props ]
  )
  // You can tell React to skip applying an effect if certain values haven’t changed between re-renders. [ props ]

  const handleInputChange = event => {
    const { name, value } = event.target//targeting the user input event

    setUser({ ...user, [name]: value })//setting each user input to its value
  }

  return (//display the output
    <div className="container">
       <div className="shadow p-5">
		<form class="form-inline"
      onSubmit={event => {
        event.preventDefault()

        props.updateUser(user.id, user)//carrying user details by Id
      }}
    >
     <label><b>Comp_Name:</b></label>
			<div className="form-group">
			<input type="text" name="name"
			     
			    required="required" 
			    className="form-control" 
			    placeholder="Enter your name" 
			    value={user.name} onChange={handleInputChange} />
			</div>
			<div className="form-group">
			<label class="one"><b>Record_Date:</b></label>
			<input type="date" name="Date_created"
			    required="required" 
			    placeholder="DD:MM:YY" 
			    className="form-control form-control-sm" 
			    value={user.Date_created} onChange={handleInputChange} />
			</div>
			<div className="form-group">
			<label><b>Time_created:</b></label>
			<input type="time" name="Time_created"
			class="clean" 
			     required="required" placeholder="H:M:S" 
			     className="form-control form-control-sm" 
			     value={user.Time_created} onChange={handleInputChange} />
			</div>
			<div className="form-group">
			<label class="adjust"><b>Operator:</b></label>
			<input type="text" name="operate" 
			     class="green"
			     required="required" placeholder="Enter operator name" 
			     className="form-control form-control-sm" 
			     value={user.operate} onChange={handleInputChange} />
			</div>
			<div className="form-group">
			<label><b>Workstation:</b></label>
			<input type="text" name="works" 
			    required="required" 
			    placeholder="Enter workstation" 
			    className="form-control form-control-sm" 
			    value={user.works} onChange={handleInputChange} />
			</div>
      <button className= "btn btn-primary mr-2" ><span class="glyphicon glyphicon-pencil">Update</span></button>
      <button onClick={() => props.setEditing(false)} className= "btn btn-danger">
      <span class="glyphicon glyphicon-trash">Cancel</span>
      </button>
    </form>
    </div>
    </div>
  )
}

export default EditUserForm;
