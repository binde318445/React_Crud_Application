import React from 'react';

class general extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            value: "coconut",
            countries: [
                {id: "1", country: "Nigeria"},
                {id: "2", country: "Ghana"},
                {id: "3", country: "UK"}
            ]

        };

        this.handleSubmit = this.handleSubmit.bind(this);
    }
        handleSubmit(event){
            alert("your favourite color is: " + this.state.value);
            event.preventDefault();
        }
        handleChange = event =>{
            this.setState({value: event.target.value});
        };
        render(){
            const countries = require("./countries.json");
            return(
                <form onSubmit = {this.handleSubmit}>
                <label>
                Pick your favourite color:
                <select value={this.state.value} onChange={this.handleChange}>
                   <option value="grapefruit"> Grapefruit </option>
                   <option value="coconu"> coconut </option>
                   <option value="lime"> lime </option>
                   <option value="mango"> mango </option>
                </select>
                </label>
                <br />
                <br />

                <label>
                Loop through Array
                <select>
                 {this.state.countries.map(item =>(
                    <option key={item.id} value={item.country}>
                    {item.country}
                    </option>
                    )
                 )
                 }
                 {console.log(this.state.countries)}
                </select>
                </label>
                <input type="submit" value="submit" />
                </form>
            );
        }
    
}
export default general;